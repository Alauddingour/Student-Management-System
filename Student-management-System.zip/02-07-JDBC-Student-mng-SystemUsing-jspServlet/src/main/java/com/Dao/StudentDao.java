package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Student;

public class StudentDao {
	private Connection con;

	public StudentDao(Connection con) {
		this.con = con;
	}

	public boolean addStudent(Student st) {
		boolean b = false;
		try {

			String sql = "insert into student (name,DOB,address,qualification,Email)values(?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, st.getName());
			ps.setString(2, st.getDob());
			ps.setString(3, st.getAdd());

			ps.setString(4, st.getQualification());
			ps.setString(5, st.getEmail());
			int i = ps.executeUpdate();
			if (i == 1) {
				b = true;
				System.out.println("Data insert");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	// Retrieve Data from table
	public List<Student> getAllStudent() {
		List<Student> list = new ArrayList<>();
		try {
			String sql = "select * from student";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Student s = new Student();
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setDob(rs.getString(3));
				s.setQualification(rs.getString(4));
				s.setQualification(rs.getString(5));
				list.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}

	// Edit the Data by id
	// Retrieve particular student data
	public Student getStudentById(int id) {
		Student s = null;
		try {
			String sql = "select * from student where id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				s = new Student();
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setDob(rs.getString(3));
				s.setQualification(rs.getString(4));
				s.setQualification(rs.getString(5));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;

	}

	public boolean editStudent(Student st) {
		boolean b = false;
		try {

			String sql = "update student set name=?,DOB=?,address=?,qualification=?,Email=? where id=?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, st.getName());
			ps.setString(2, st.getDob());
			ps.setString(3, st.getAdd());

			ps.setString(4, st.getQualification());
			ps.setString(5, st.getEmail());
			ps.setInt(6, st.getId());
			int i = ps.executeUpdate();
			if (i == 1) {
				b = true;
				System.out.println("Data insert");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	public boolean deleteStudent(int id) {
		boolean b = false;
		try {
			String sql = "delete from student where id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			int i = ps.executeUpdate();
			if (i == 1) {
				b = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

}

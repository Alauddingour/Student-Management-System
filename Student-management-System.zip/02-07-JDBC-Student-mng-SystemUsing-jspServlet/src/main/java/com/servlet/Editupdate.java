package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.StudentDao;
import com.conn.DbCon;
import com.entity.Student;
@WebServlet("/update")
public class Editupdate extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String dob = req.getParameter("DOB");
		String address = req.getParameter("add");
		String qua = req.getParameter("qualification");
		String Email = req.getParameter("mail");
		int id=Integer.parseInt(req.getParameter("id"));
		Student st = new Student( id,name, dob, address, qua, Email);
	   
		StudentDao std = new StudentDao(DbCon.getCon());

		boolean b = std.editStudent(st);
		HttpSession session=req.getSession();
		resp.sendRedirect("index.jsp");
	}

}

 package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.StudentDao;
import com.conn.DbCon;
import com.entity.Student;

@WebServlet("/register")
public class RegisterSeervlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String dob = req.getParameter("DOB");
		String address = req.getParameter("add");
		String qua = req.getParameter("qualification");
		String Email = req.getParameter("mail");

		Student st = new Student(name, dob, address, qua, Email);
		System.out.println(st);
		StudentDao std = new StudentDao(DbCon.getCon());
		//HttpSession s = req.getSession();
		boolean b = std.addStudent(st);
		if (b) {
			//s.setAttribute("succMsg", "Student details Submit Successfully");
            //resp.sendRedirect("add-stu.jsp");
			System.out.println("Add Successfully");
		} else 
			 //s.setAttribute("errorMsg", "somthing went wrong on server");
             // resp.sendRedirect("add-stu.jsp");
			System.out.println("somthing wrong sevlet");

	}

}

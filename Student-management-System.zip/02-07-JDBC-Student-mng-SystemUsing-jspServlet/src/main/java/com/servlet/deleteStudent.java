package com.servlet;

import java.io.IOException;
import com.Dao.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.StudentDao;
import com.conn.DbCon;
@WebServlet("/delete")
public class deleteStudent extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 int id=Integer.parseInt(req.getParameter("id"));
		 StudentDao std=new StudentDao(DbCon.getCon());
		boolean bi= std.deleteStudent(id);
		if(bi)
		{
			resp.sendRedirect("index.jsp");
		}
	}

}
